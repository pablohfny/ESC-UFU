iverilog -o tb_alu.vvp tb_alu.v alu.v
vvp tb_alu.vvp